NULLLATTE MEDIA KIT

作品タイトル：ふた文字、貢げ！
制作者：NULLLATTE

【収録素材】
- character_01.png
- character_02.png
- character_03.png
- character_04.png
- screenshot_01.png
- screenshot_02.png

実況動画・ライブ配信のサムネイルや、作品紹介にご利用いただけます。
動画・配信の概要欄などに、ゲームタイトル・作者名（NULLLATTE）・ゲームページのURLを記載してください。
素材単体の再配布・販売は禁止です。

ゲームページ：https://unityroom.com/games/futamoji-mitsuge
実況・配信ガイドライン：https://hellonulllatte-dev.github.io/games.html#streaming-policy

--- English ---

Title: ふた文字、貢げ！
Creator: NULLLATTE

Included assets:
- character_01.png
- character_02.png
- character_03.png
- character_04.png
- screenshot_01.png
- screenshot_02.png

You may use these assets in thumbnails for gameplay videos and streams, and when introducing the game.
Please include the game title, creator name (NULLLATTE), and game page URL in the video or stream description.
Redistribution or sale of these assets on their own is prohibited.

Game page: https://unityroom.com/games/futamoji-mitsuge
Streaming guidelines: https://hellonulllatte-dev.github.io/games.html#streaming-policy
